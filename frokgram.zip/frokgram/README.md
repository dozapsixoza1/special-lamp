# 🐸 Frokgram - Мобильный Мессенджер

Простой мессенджер на React Native/Expo с Firebase бэком. Встроенный бот, личные чаты, управление устройствами.

## 🚀 Быстрый старт

### 1. Требования
- Node.js 18+
- EAS Account (бесплатно)
- Firebase Project
- GitHub для CI/CD

### 2. Setup Firebase

```bash
# 1. Создай проект на console.firebase.google.com
# 2. Enable: Authentication (Anonymous) + Firestore Database
# 3. Copy firebaseConfig из Settings > Project settings
# 4. Вставь config в App.js (строка 9-20)
```

### 3. Локальный запуск

```bash
npm install
npx expo start
# Сканируй QR кодом в Expo Go app
```

### 4. Build на GitHub Actions

#### Первый раз:
```bash
eas login
eas build:configure
# Выбери Android
# Скопируй Project ID из eas.json
git add . && git commit -m "Initial commit"
git push origin main
```

#### GitHub Secrets (Settings > Secrets > Actions):
```
EAS_TOKEN=<твой eas токен из ~/.eas/auth.json>
TELEGRAM_BOT_TOKEN=<опционально для уведомлений>
TELEGRAM_CHAT_ID=<опционально для уведомлений>
```

#### Автоматический build:
- Пиши код → Push → GitHub Actions builds APK
- APK скачивается в Artifacts
- Отправляется в Telegram (если настроено)

## 📁 Структура

```
frokgram/
├── App.js                 # Основной код приложения
├── app.json              # Expo конфиг
├── eas.json              # EAS Build конфиг
├── package.json          # Dependencies
├── .github/
│   └── workflows/
│       └── build.yml     # GitHub Actions workflow
├── .gitignore
├── .env.example          # Пример переменных окружения
└── README.md             # Этот файл
```

## ⚙️ Конфигурация

### Firebase Config (App.js)

Замени на свои значения:

```javascript
const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "your-project.firebaseapp.com",
  projectId: "your-project",
  storageBucket: "your-project.appspot.com",
  messagingSenderId: "YOUR_ID",
  appId: "YOUR_APP_ID",
};
```

### Firestore Rules

```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /users/{userId} {
      allow read: if request.auth.uid == userId;
      allow write: if request.auth.uid == userId;
      allow create: if true;
    }
    match /chats/{chatId} {
      allow read, write: if request.auth.uid != null;
      allow create: if request.auth.uid != null;
    }
    match /messages/{messageId} {
      allow read, write: if request.auth.uid != null;
      allow create: if request.auth.uid != null;
    }
    match /{document=**} {
      allow read, write: if false;
    }
  }
}
```

## 📱 Функционал

✅ Регистрация с рандомным ID  
✅ Вход по ID  
✅ Личные чаты 1v1  
✅ Встроенный бот @FrokgramBot  
✅ Сообщения в реал-тайме  
✅ Device Management (кик после 6 часов)  
✅ Settings + Logout  

## 🔧 Как работает

### Регистрация
1. Вводишь никнейм
2. Приложение создаёт рандомный ID
3. Создаётся чат с ботом
4. Бот отправляет приветствие с ID

### Вход
1. Вводишь свой ID
2. Приложение создаёт новую сессию (device)
3. Входишь в аккаунт

### Чаты
1. Создаёшь чат по никнейму
2. Отправляешь сообщения
3. Firestore слушает обновления в реал-тайме

### Device Management
- Каждое устройство = одна сессия
- Минимум 6 часов для удаления устройства
- Кикнуть → удалить из devices[]

## 📦 Build локально

```bash
# Development APK
eas build --platform android --profile preview

# Production AAB (для Google Play)
eas build --platform android --profile production

# Install on device
adb install frokgram.apk
```

## 🔑 GitHub Actions Workflow

```yaml
# .github/workflows/build.yml
- Trigger: Push на main/develop или manual
- Build: EAS builds APK через облако
- Download: Скачивает готовый APK
- Upload: Artifact в GitHub
- Telegram: Отправляет APK в чат (опционально)
- Release: Если есть tag, создаёт Release
```

## 📊 Структура Data (Firestore)

### users/{uid}
```json
{
  "username": "string",
  "frokgramId": "random-id",
  "createdAt": "timestamp",
  "currentSession": "session-id",
  "devices": [
    {
      "id": "session-id",
      "createdAt": "timestamp",
      "lastActive": "timestamp",
      "ip": "mobile-app"
    }
  ],
  "blockedUsers": []
}
```

### chats/{id}
```json
{
  "participants": ["user1", "user2"],
  "createdAt": "timestamp",
  "lastMessage": "string",
  "lastMessageTime": "timestamp"
}
```

### messages/{id}
```json
{
  "chatId": "chat-id",
  "sender": "username",
  "text": "string",
  "timestamp": "timestamp"
}
```

## 🐛 Troubleshooting

| Ошибка | Решение |
|--------|---------|
| Firebase not initializing | Проверь firebaseConfig в App.js |
| EAS build fails | `npm install firebase@latest` |
| APK doesn't download | Проверь EAS_TOKEN в GitHub Secrets |
| App crashes on start | Проверь Firestore Rules |

## 📝 Environment Variables

```bash
# .env
FIREBASE_API_KEY=...
FIREBASE_PROJECT_ID=...
EAS_TOKEN=...
```

## 🚢 Deployment

### Google Play
1. Создай Google Play Developer Account ($25)
2. Создай приложение
3. Upload AAB (Production build)
4. Заполни информацию + скриншоты
5. Submit for review

### Тестирование перед upload
```bash
eas build --platform android --profile preview
# Тестируй на реальном девайсе
```

## 📞 Контакты

**Developer:** psychokaratel  
**In-app Bot:** @FrokgramBot  
**GitHub:** [твой репо]

## 📄 Лицензия

MIT

---

**Нужна помощь?** Открой Issue на GitHub или напиши в чат приложения! 🐸
