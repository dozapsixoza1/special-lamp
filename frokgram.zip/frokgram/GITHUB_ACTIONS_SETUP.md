# 🚀 GitHub Actions CI/CD Setup для Frokgram

## 1️⃣ Подготовка EAS

```bash
# Установить EAS CLI
npm i -g eas-cli

# Зарегистрироваться
eas login
# Email + пароль

# Настроить проект
eas build:configure
# Выбери Android
# Ответь на вопросы

# Получить токен для GitHub Actions
cat ~/.eas/auth.json | jq .
# Скопируй содержимое auth.json
```

## 2️⃣ GitHub Setup

### Создать репозиторий

```bash
git init
git add .
git commit -m "Initial commit"
git remote add origin https://github.com/psychokaratel/frokgram.git
git branch -M main
git push -u origin main
```

### Добавить Secrets

1. Открыть GitHub репо
2. Settings > Secrets and variables > Actions
3. Нажать "New repository secret"

Добавить эти секреты:

#### EAS_TOKEN (обязательно)
```
Имя: EAS_TOKEN
Значение: (содержимое ~/.eas/auth.json)
```

Пример:
```json
{"auth": {"sessionSecret": "...", "userId": "...", ...}}
```

Или просто токен:
```
eas_mq_..._eas
```

#### TELEGRAM_BOT_TOKEN (опционально)
```
Имя: TELEGRAM_BOT_TOKEN
Значение: 123456:ABC-DEF... (от @BotFather)
```

#### TELEGRAM_CHAT_ID (опционально)
```
Имя: TELEGRAM_CHAT_ID
Значение: -1001234567890 (твой chat ID)
```

## 3️⃣ Как работает Build

### Автоматический запуск

Build запускается при:
- Push на `main` или `develop`
- Manual trigger (Actions > Run workflow)

### Процесс

1. **Checkout** — скачивает код из GitHub
2. **Setup Node** — устанавливает Node 18
3. **Install EAS** — ставит eas-cli
4. **Install Dependencies** — `npm install`
5. **Setup EAS Auth** — использует EAS_TOKEN
6. **Build Android** — `eas build --platform android`
7. **Download APK** — скачивает готовый файл
8. **Upload Artifact** — сохраняет в GitHub (30 дней)
9. **Telegram Notification** — отправляет APK в чат (если настроено)

## 4️⃣ Скачать APK из GitHub

### Вариант 1: Из Artifacts

1. GitHub > Actions
2. Выбрать последний workflow run
3. Скроллить вниз до "Artifacts"
4. Нажать "frokgram-apk"
5. Скачать ZIP и распаковать

### Вариант 2: Из Telegram

Если настроен TELEGRAM_BOT_TOKEN и TELEGRAM_CHAT_ID:
- APK автоматически отправляется в чат
- Можно скачать прямо из Telegram

### Вариант 3: EAS Dashboard

1. Открыть [expo.dev](https://expo.dev)
2. Logged In > Project > Builds
3. Нажать на последний build
4. Скачать APK оттуда

## 5️⃣ Установить APK на телефон

### Через USB

```bash
adb install frokgram.apk
```

### Через файловую систему

1. Скопировать APK на телефон
2. Открыть Файлы
3. Найти APK
4. Нажать Install

### Через Build APK Assistant (EAS)

```bash
eas build:list --platform android
# Выбрать и скачать последний APK
```

## 6️⃣ Environment Variables в App.js

### Использование .env

```javascript
// App.js
import { getEnvVars } from './env';

const { firebaseConfig } = getEnvVars();
```

Или напрямую:

```javascript
const firebaseConfig = {
  apiKey: process.env.FIREBASE_API_KEY || 'YOUR_API_KEY',
  // ...
};
```

## 7️⃣ Кастомизация Workflow

### Изменить условие запуска

```yaml
# build.yml line 5-8
on:
  push:
    branches:
      - main        # только main
      - develop     # или develop
      - 'release/*' # или релизные ветки
```

### Отключить Telegram уведомления

```yaml
# build.yml line 62-70
# Удалить или закомментировать раздел "Upload to Telegram"
```

### Добавить email уведомления

```yaml
- name: Send Email
  if: failure()
  uses: dawidd6/action-send-mail@v3
  with:
    server_address: smtp.gmail.com
    server_port: 465
    username: ${{ secrets.EMAIL_USERNAME }}
    password: ${{ secrets.EMAIL_PASSWORD }}
    to: your-email@gmail.com
    subject: "Build Failed"
    body: "Frokgram build failed"
```

## 8️⃣ Troubleshooting

| Проблема | Решение |
|----------|---------|
| Build fails - "EAS_TOKEN invalid" | Проверь что скопировал весь auth.json в Secrets |
| Build timeout | Увеличь timeout в build.yml (строка 9) |
| APK download fails | Проверь что eas build успешен в логах |
| Telegram upload fails | Проверь TELEGRAM_BOT_TOKEN и CHAT_ID |
| App crashes | Проверь firebaseConfig и Firestore Rules |

## 9️⃣ Версионирование

### Автоматическое увеличение версии

```yaml
# Добавить перед build step
- name: Bump version
  run: |
    VERSION=$(npm pkg get version | tr -d '"')
    MINOR=$(echo $VERSION | cut -d. -f2)
    MINOR=$((MINOR + 1))
    NEW_VERSION="1.$MINOR.0"
    npm pkg set version=$NEW_VERSION
```

### Создание Release

```bash
git tag v1.0.1
git push origin v1.0.1
# GitHub Actions автоматически создаст Release с APK
```

## 🔟 Мониторинг

### Проверить статус builds

```bash
eas build:list --platform android --limit 10
```

### Посмотреть logs

```bash
eas build:view <build-id>
```

### Real-time logs

```bash
eas build:watch <build-id>
```

---

**Готово! Теперь:**

1. Push код → GitHub Actions автоматически buildит
2. Скачиваешь APK из Artifacts или Telegram
3. Устанавливаешь на телефон
4. Тестируешь

**Вопросы?** Проверь логи в GitHub Actions (Actions tab)
