import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  FlatList,
  ScrollView,
  Alert,
  StyleSheet,
  KeyboardAvoidingView,
  Platform,
  ActivityIndicator,
} from 'react-native';
import { initializeApp } from 'firebase/app';
import {
  getAuth,
  signInAnonymously,
  onAuthStateChanged,
} from 'firebase/auth';
import {
  getFirestore,
  collection,
  addDoc,
  getDocs,
  doc,
  getDoc,
  setDoc,
  updateDoc,
  query,
  where,
  orderBy,
  onSnapshot,
  deleteDoc,
  Timestamp,
} from 'firebase/firestore';

// Firebase config
const firebaseConfig = {
  apiKey: 'YOUR_API_KEY',
  authDomain: 'YOUR_AUTH_DOMAIN',
  projectId: 'YOUR_PROJECT_ID',
  storageBucket: 'YOUR_STORAGE_BUCKET',
  messagingSenderId: 'YOUR_MESSAGING_SENDER_ID',
  appId: 'YOUR_APP_ID',
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

const DEVICE_TIMEOUT = 6 * 60 * 60 * 1000; // 6 hours

export default function FrokgramApp() {
  const [screen, setScreen] = useState('auth'); // auth, register, home
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      if (firebaseUser) {
        const userDoc = await getDoc(doc(db, 'users', firebaseUser.uid));
        if (userDoc.exists()) {
          setUser({ uid: firebaseUser.uid, ...userDoc.data() });
          setScreen('home');
        } else {
          setScreen('register');
        }
      } else {
        setUser(null);
        setScreen('auth');
      }
      setLoading(false);
    });
    return unsubscribe;
  }, []);

  if (loading) {
    return (
      <View style={styles.container}>
        <ActivityIndicator size="large" color="#007AFF" />
      </View>
    );
  }

  if (screen === 'auth') {
    return <AuthScreen onRegister={() => setScreen('register')} />;
  }

  if (screen === 'register') {
    return <RegisterScreen onSuccess={() => setUser(auth.currentUser)} />;
  }

  return <HomeScreen user={user} setUser={setUser} />;
}

// Auth Screen (вход по ID)
function AuthScreen({ onRegister }) {
  const [id, setId] = useState('');
  const [loading, setLoading] = useState(false);

  const handleLogin = async () => {
    if (!id.trim()) {
      Alert.alert('Error', 'Введи ID');
      return;
    }

    setLoading(true);
    try {
      const usersRef = collection(db, 'users');
      const q = query(where('frokgramId', '==', id.trim()));
      const snapshot = await getDocs(q);

      if (snapshot.empty) {
        Alert.alert('Error', 'ID не найден');
        setLoading(false);
        return;
      }

      const userDoc = snapshot.docs[0];
      const userData = userDoc.data();

      // Create session
      const sessionId = Math.random().toString(36).substring(7);
      const deviceTimestamp = Timestamp.now();

      await updateDoc(doc(db, 'users', userDoc.id), {
        currentSession: sessionId,
        devices: [
          ...(userData.devices || []),
          {
            id: sessionId,
            createdAt: deviceTimestamp,
            lastActive: deviceTimestamp,
            ip: 'mobile-app',
          },
        ],
      });

      await signInAnonymously(auth);
      Alert.alert('Success', 'Вошёл в аккаунт!');
    } catch (error) {
      Alert.alert('Error', error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Frokgram 🐸</Text>
      <Text style={styles.subtitle}>Вход</Text>

      <TextInput
        style={styles.input}
        placeholder="Введи свой ID"
        value={id}
        onChangeText={setId}
        editable={!loading}
      />

      <TouchableOpacity
        style={[styles.button, loading && styles.buttonDisabled]}
        onPress={handleLogin}
        disabled={loading}
      >
        <Text style={styles.buttonText}>
          {loading ? 'Загрузка...' : 'Войти'}
        </Text>
      </TouchableOpacity>

      <TouchableOpacity onPress={onRegister}>
        <Text style={styles.link}>Нет аккаунта? Зарегистрируйся</Text>
      </TouchableOpacity>
    </View>
  );
}

// Register Screen
function RegisterScreen({ onSuccess }) {
  const [username, setUsername] = useState('');
  const [loading, setLoading] = useState(false);

  const generateId = () => {
    return Math.random().toString(36).substring(2, 11);
  };

  const handleRegister = async () => {
    if (!username.trim()) {
      Alert.alert('Error', 'Введи никнейм');
      return;
    }

    setLoading(true);
    try {
      const frokgramId = generateId();

      // Sign in first
      const result = await signInAnonymously(auth);
      const uid = result.user.uid;

      const sessionId = Math.random().toString(36).substring(7);
      const deviceTimestamp = Timestamp.now();

      // Create user doc
      await setDoc(doc(db, 'users', uid), {
        username: username.trim(),
        frokgramId,
        createdAt: deviceTimestamp,
        currentSession: sessionId,
        devices: [
          {
            id: sessionId,
            createdAt: deviceTimestamp,
            lastActive: deviceTimestamp,
            ip: 'mobile-app',
          },
        ],
        blockedUsers: [],
      });

      // Bot автоматически отправляет сообщение в чат с системой
      const botChatId = [username.trim(), '@FrokgramBot'].sort().join('_');
      await setDoc(doc(db, 'chats', botChatId), {
        participants: [username.trim(), '@FrokgramBot'],
        createdAt: deviceTimestamp,
        lastMessage: '',
        lastMessageTime: deviceTimestamp,
      });

      await addDoc(collection(db, 'messages'), {
        chatId: botChatId,
        sender: '@FrokgramBot',
        text: `Добро пожаловать в Frokgram! 🎉\n\nТвой ID: ${frokgramId}\n\nЭто твой уникальный ID для входа. Не теряй!`,
        timestamp: deviceTimestamp,
      });

      Alert.alert('Success', `Аккаунт создан! 🎉\n\nТвой ID: ${frokgramId}\n\nПроверь чат с ботом @FrokgramBot`);
      onSuccess();
    } catch (error) {
      Alert.alert('Error', error.message);
    } finally {
      setLoading(false);
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Frokgram 🐸</Text>
      <Text style={styles.subtitle}>Регистрация</Text>

      <TextInput
        style={styles.input}
        placeholder="Никнейм"
        value={username}
        onChangeText={setUsername}
        editable={!loading}
      />

      <TouchableOpacity
        style={[styles.button, loading && styles.buttonDisabled]}
        onPress={handleRegister}
        disabled={loading}
      >
        <Text style={styles.buttonText}>
          {loading ? 'Загрузка...' : 'Зарегистрироваться'}
        </Text>
      </TouchableOpacity>
    </View>
  );
}

// Home Screen (чаты + настройки)
function HomeScreen({ user, setUser }) {
  const [tab, setTab] = useState('chats'); // chats, settings
  const [chats, setChats] = useState([]);
  const [selectedChat, setSelectedChat] = useState(null);
  const [message, setMessage] = useState('');

  useEffect(() => {
    if (!user) return;

    const q = query(
      collection(db, 'chats'),
      where('participants', 'array-contains', user.username)
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      const chatList = snapshot.docs.map((doc) => ({
        id: doc.id,
        ...doc.data(),
      }));
      setChats(chatList);
    });

    return unsubscribe;
  }, [user]);

  const handleSendMessage = async () => {
    if (!message.trim() || !selectedChat) return;

    try {
      await addDoc(collection(db, 'messages'), {
        chatId: selectedChat.id,
        sender: user.username,
        text: message.trim(),
        timestamp: Timestamp.now(),
      });
      setMessage('');
    } catch (error) {
      Alert.alert('Error', error.message);
    }
  };

  const handleNewChat = async () => {
    const username = prompt('Введи никнейм пользователя');
    if (!username) return;

    try {
      const usersRef = collection(db, 'users');
      const q = query(where('username', '==', username));
      const snapshot = await getDocs(q);

      if (snapshot.empty) {
        Alert.alert('Error', 'Пользователь не найден');
        return;
      }

      const chatId = [user.username, username].sort().join('_');
      await setDoc(doc(db, 'chats', chatId), {
        participants: [user.username, username],
        createdAt: Timestamp.now(),
        lastMessage: '',
        lastMessageTime: Timestamp.now(),
      });

      Alert.alert('Success', 'Чат создан!');
    } catch (error) {
      Alert.alert('Error', error.message);
    }
  };

  if (tab === 'settings') {
    return (
      <SettingsScreen user={user} setUser={setUser} onBack={() => setTab('chats')} />
    );
  }

  if (selectedChat) {
    return (
      <ChatScreen
        chat={selectedChat}
        user={user}
        message={message}
        setMessage={setMessage}
        onSend={handleSendMessage}
        onBack={() => setSelectedChat(null)}
      />
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.title}>Frokgram 🐸</Text>
        <TouchableOpacity onPress={() => setTab('settings')}>
          <Text style={styles.settingsBtn}>⚙️</Text>
        </TouchableOpacity>
      </View>

      <TouchableOpacity style={styles.newChatBtn} onPress={handleNewChat}>
        <Text style={styles.newChatBtnText}>+ Новый чат</Text>
      </TouchableOpacity>

      <FlatList
        data={chats}
        keyExtractor={(item) => item.id}
        renderItem={({ item }) => (
          <TouchableOpacity
            style={styles.chatItem}
            onPress={() => setSelectedChat(item)}
          >
            <Text style={styles.chatName}>
              {item.participants.find((p) => p !== user.username)}
            </Text>
            <Text style={styles.chatPreview}>{item.lastMessage || 'Нет сообщений'}</Text>
          </TouchableOpacity>
        )}
        ListEmptyComponent={
          <Text style={styles.emptyText}>Нет чатов. Создай новый! 👇</Text>
        }
      />
    </View>
  );
}

// Chat Screen
function ChatScreen({ chat, user, message, setMessage, onSend, onBack }) {
  const [messages, setMessages] = useState([]);

  useEffect(() => {
    const q = query(
      collection(db, 'messages'),
      where('chatId', '==', chat.id),
      orderBy('timestamp', 'asc')
    );

    const unsubscribe = onSnapshot(q, (snapshot) => {
      setMessages(snapshot.docs.map((doc) => doc.data()));
    });

    return unsubscribe;
  }, [chat]);

  return (
    <KeyboardAvoidingView
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
      style={styles.container}
    >
      <View style={styles.chatHeader}>
        <TouchableOpacity onPress={onBack}>
          <Text style={styles.backBtn}>← Назад</Text>
        </TouchableOpacity>
        <Text style={styles.chatHeaderTitle}>
          {chat.participants.find((p) => p !== user.username)}
        </Text>
      </View>

      <FlatList
        data={messages}
        keyExtractor={(_, idx) => idx.toString()}
        renderItem={({ item }) => (
          <View
            style={[
              styles.messageBubble,
              item.sender === user.username
                ? styles.messageSent
                : styles.messageReceived,
            ]}
          >
            {item.sender !== user.username && (
              <Text style={styles.senderName}>{item.sender}</Text>
            )}
            <Text style={styles.messageText}>{item.text}</Text>
          </View>
        )}
      />

      <View style={styles.inputContainer}>
        <TextInput
          style={styles.messageInput}
          placeholder="Сообщение..."
          value={message}
          onChangeText={setMessage}
          multiline
        />
        <TouchableOpacity style={styles.sendBtn} onPress={onSend}>
          <Text style={styles.sendBtnText}>Отправить</Text>
        </TouchableOpacity>
      </View>
    </KeyboardAvoidingView>
  );
}

// Settings Screen (Device Management)
function SettingsScreen({ user, setUser, onBack }) {
  const [devices, setDevices] = useState(user?.devices || []);
  const [loading, setLoading] = useState(false);

  const formatDate = (timestamp) => {
    if (!timestamp) return 'Unknown';
    const date = timestamp.toDate ? timestamp.toDate() : new Date(timestamp);
    return date.toLocaleString('ru-RU');
  };

  const canKickDevice = (device) => {
    if (!device.createdAt) return false;
    const deviceAge = Date.now() - (device.createdAt.toDate ? device.createdAt.toDate() : new Date(device.createdAt)).getTime();
    return deviceAge >= DEVICE_TIMEOUT;
  };

  const handleKickDevice = async (deviceId) => {
    if (!canKickDevice(devices.find((d) => d.id === deviceId))) {
      Alert.alert('Error', 'Можно кикать только устройства старше 6 часов');
      return;
    }

    setLoading(true);
    try {
      const updatedDevices = devices.filter((d) => d.id !== deviceId);
      await updateDoc(doc(db, 'users', user.uid), {
        devices: updatedDevices,
      });
      setDevices(updatedDevices);
      Alert.alert('Success', 'Устройство удалено');
    } catch (error) {
      Alert.alert('Error', error.message);
    } finally {
      setLoading(false);
    }
  };

  const handleLogout = async () => {
    await auth.signOut();
    setUser(null);
  };

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={onBack}>
          <Text style={styles.backBtn}>← Назад</Text>
        </TouchableOpacity>
        <Text style={styles.title}>Настройки</Text>
      </View>

      <ScrollView style={styles.settingsContent}>
        <Text style={styles.sectionTitle}>Твой профиль</Text>
        <View style={styles.profileCard}>
          <Text style={styles.profileLabel}>Никнейм:</Text>
          <Text style={styles.profileValue}>{user.username}</Text>
          <Text style={styles.profileLabel}>ID:</Text>
          <Text style={styles.profileValue}>{user.frokgramId}</Text>
        </View>

        <Text style={styles.sectionTitle}>Устройства ({devices.length})</Text>
        {devices.map((device) => {
          const age = Date.now() - (device.createdAt.toDate ? device.createdAt.toDate() : new Date(device.createdAt)).getTime();
          const canKick = canKickDevice(device);

          return (
            <View key={device.id} style={styles.deviceCard}>
              <Text style={styles.deviceName}>{device.ip}</Text>
              <Text style={styles.deviceTime}>
                Добавлено: {formatDate(device.createdAt)}
              </Text>
              <Text style={styles.deviceTime}>
                Возраст: {Math.floor(age / 3600000)} ч
              </Text>
              <TouchableOpacity
                style={[styles.kickBtn, !canKick && styles.kickBtnDisabled]}
                onPress={() => handleKickDevice(device.id)}
                disabled={!canKick || loading}
              >
                <Text style={styles.kickBtnText}>
                  {canKick ? 'Кикнуть' : 'Ещё не готово'}
                </Text>
              </TouchableOpacity>
            </View>
          );
        })}

        <TouchableOpacity style={styles.logoutBtn} onPress={handleLogout}>
          <Text style={styles.logoutBtnText}>Выход</Text>
        </TouchableOpacity>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f5f5f5',
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingTop: 16,
    paddingBottom: 12,
    backgroundColor: '#007AFF',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#fff',
  },
  subtitle: {
    fontSize: 16,
    color: '#666',
    marginVertical: 20,
  },
  input: {
    backgroundColor: '#fff',
    borderRadius: 8,
    padding: 12,
    marginVertical: 10,
    marginHorizontal: 16,
    borderWidth: 1,
    borderColor: '#ddd',
    fontSize: 16,
  },
  button: {
    backgroundColor: '#007AFF',
    borderRadius: 8,
    padding: 14,
    marginHorizontal: 16,
    marginTop: 20,
  },
  buttonDisabled: {
    opacity: 0.6,
  },
  buttonText: {
    color: '#fff',
    textAlign: 'center',
    fontWeight: 'bold',
    fontSize: 16,
  },
  link: {
    color: '#007AFF',
    textAlign: 'center',
    marginTop: 20,
    fontSize: 14,
  },
  info: {
    fontSize: 12,
    color: '#999',
    marginHorizontal: 16,
    marginVertical: 8,
  },
  settingsBtn: {
    fontSize: 24,
  },
  newChatBtn: {
    backgroundColor: '#34C759',
    marginHorizontal: 16,
    marginVertical: 10,
    paddingVertical: 12,
    borderRadius: 8,
  },
  newChatBtnText: {
    color: '#fff',
    textAlign: 'center',
    fontWeight: 'bold',
  },
  chatItem: {
    backgroundColor: '#fff',
    padding: 12,
    marginHorizontal: 8,
    marginVertical: 4,
    borderRadius: 8,
    borderBottomWidth: 1,
    borderBottomColor: '#eee',
  },
  chatName: {
    fontWeight: 'bold',
    fontSize: 16,
  },
  chatPreview: {
    color: '#999',
    fontSize: 13,
    marginTop: 4,
  },
  emptyText: {
    textAlign: 'center',
    color: '#999',
    marginTop: 50,
  },
  chatHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#007AFF',
    paddingHorizontal: 16,
    paddingVertical: 12,
  },
  chatHeaderTitle: {
    color: '#fff',
    fontWeight: 'bold',
    fontSize: 18,
    flex: 1,
    textAlign: 'center',
  },
  backBtn: {
    color: '#007AFF',
    fontSize: 16,
    fontWeight: 'bold',
  },
  messageBubble: {
    marginVertical: 4,
    marginHorizontal: 8,
    padding: 10,
    borderRadius: 12,
    maxWidth: '80%',
  },
  messageSent: {
    alignSelf: 'flex-end',
    backgroundColor: '#007AFF',
  },
  messageReceived: {
    alignSelf: 'flex-start',
    backgroundColor: '#e5e5ea',
  },
  senderName: {
    fontSize: 12,
    fontWeight: 'bold',
    marginBottom: 4,
    color: '#666',
  },
  messageText: {
    fontSize: 14,
    color: '#fff',
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    padding: 10,
    backgroundColor: '#fff',
    borderTopWidth: 1,
    borderTopColor: '#eee',
  },
  messageInput: {
    flex: 1,
    backgroundColor: '#f5f5f5',
    borderRadius: 8,
    paddingHorizontal: 12,
    paddingVertical: 8,
    marginRight: 8,
    maxHeight: 100,
  },
  sendBtn: {
    backgroundColor: '#007AFF',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 8,
  },
  sendBtnText: {
    color: '#fff',
    fontWeight: 'bold',
  },
  settingsContent: {
    flex: 1,
    padding: 16,
  },
  sectionTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginTop: 16,
    marginBottom: 10,
  },
  profileCard: {
    backgroundColor: '#fff',
    padding: 12,
    borderRadius: 8,
    marginBottom: 16,
  },
  profileLabel: {
    fontSize: 12,
    color: '#999',
    marginTop: 8,
  },
  profileValue: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#333',
  },
  deviceCard: {
    backgroundColor: '#fff',
    padding: 12,
    borderRadius: 8,
    marginBottom: 10,
  },
  deviceName: {
    fontWeight: 'bold',
    fontSize: 14,
  },
  deviceTime: {
    fontSize: 12,
    color: '#999',
    marginTop: 4,
  },
  kickBtn: {
    backgroundColor: '#FF3B30',
    paddingVertical: 8,
    borderRadius: 6,
    marginTop: 8,
  },
  kickBtnDisabled: {
    backgroundColor: '#ccc',
  },
  kickBtnText: {
    color: '#fff',
    textAlign: 'center',
    fontWeight: 'bold',
    fontSize: 13,
  },
  logoutBtn: {
    backgroundColor: '#FF3B30',
    paddingVertical: 12,
    borderRadius: 8,
    marginTop: 30,
  },
  logoutBtnText: {
    color: '#fff',
    textAlign: 'center',
    fontWeight: 'bold',
    fontSize: 16,
  },
});
